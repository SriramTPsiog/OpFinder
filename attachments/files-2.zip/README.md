# Masters Scout
Daily autonomous agent that finds Master's programs and scholarships (electronics, circuits, semiconductors,
embedded) in UK, Malaysia, Singapore, Japan, China, Taiwan, Denmark + other countries, scored for your profile.

## Setup (10 min, free)
1. Create a private GitHub repo and upload this folder.
2. Repo > Settings > Secrets > Actions: add `ANTHROPIC_API_KEY` (from console.anthropic.com),
   and optionally `SMTP_USER` (your Gmail), `SMTP_PASS` (Gmail App Password), `MAIL_TO`.
3. Actions tab > "Masters Scout" > Run workflow. It then runs every day at 08:00 IST.
4. Settings > Pages > deploy from `main` / `docs` for a live dashboard.

## Outputs
- Email digest: new matches + deadlines closing in 30 days
- `docs/index.html` dashboard, `applications.csv` apply-list (sorted by fit)
- `data/opportunities.json`: set `"status"` to `applied` / `ignored` to track progress

## Tune it
Edit `profile.json` (fields, regions, priorities). Env `MIN_SCORE` (default 55) controls strictness.
Run locally: `pip install anthropic && export ANTHROPIC_API_KEY=... && python scout.py`

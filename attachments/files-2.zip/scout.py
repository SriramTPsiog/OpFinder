#!/usr/bin/env python3
"""Masters Scout: daily autonomous search for Master's programs & scholarships.
Uses Claude + live web search, scores fit against profile.json, dedupes, emails a digest,
and maintains data/opportunities.json, applications.csv and docs/index.html."""
import os, re, json, csv, time, hashlib, smtplib, datetime as dt
from email.mime.text import MIMEText
from html import escape
from pathlib import Path
import anthropic

ROOT = Path(__file__).parent
DATA, DOCS = ROOT / "data", ROOT / "docs"
DATA.mkdir(exist_ok=True); DOCS.mkdir(exist_ok=True)
DB = DATA / "opportunities.json"
MODEL = os.getenv("MODEL", "claude-sonnet-5-5")
MIN_SCORE = int(os.getenv("MIN_SCORE", "55"))
TODAY = dt.date.today()
profile = json.loads((ROOT / "profile.json").read_text())
client = anthropic.Anthropic()

SYSTEM = f"""You are a meticulous graduate-admissions research agent working for ONE applicant.
Applicant profile: {json.dumps(profile)}
Today is {TODAY.isoformat()}. Use web search to find REAL, CURRENTLY OPEN or soon-to-open (application deadline on/after today,
or opening for the 2027 intake) Master's programs AND scholarships in the requested region.
Prefer official university / government pages. Never invent URLs or deadlines; if unknown use null.
Return ONLY a JSON array (no prose, no markdown fences) of up to 12 objects with keys:
title, institution, country, kind ("program"|"scholarship"|"both"), field, deadline (YYYY-MM-DD or null),
intake, funding (short), url (official), fit_score (0-100 for THIS applicant), why_fit (1-2 sentences),
risks (eligibility gaps e.g. minimum grade, language tests, GRE; short), part_time_or_online (true/false)."""

def key(o):
    u = re.sub(r"^https?://(www\.)?|[#?].*$|/$", "", (o.get("url") or "").lower())
    return hashlib.md5((u or (o.get("title","")+o.get("institution",""))).lower().encode()).hexdigest()[:12]

def scout(region):
    prompt = (f"Region: {region}. Find new/open Master's programs and scholarships in electronics, circuits, "
              f"semiconductors/microelectronics, embedded/IoT and related fields. Search for current application "
              f"cycles, scholarship calls and newly announced programs (last 30 days preferred). JSON array only.")
    msgs = [{"role": "user", "content": prompt}]
    for _ in range(3):
        r = client.messages.create(model=MODEL, max_tokens=6000, system=SYSTEM, messages=msgs,
            tools=[{"type": "web_search_20250305", "name": "web_search", "max_uses": 6}])
        text = "".join(b.text for b in r.content if b.type == "text")
        m = re.search(r"\[.*\]", text, re.S)
        if m:
            try: return json.loads(m.group(0))
            except json.JSONDecodeError: pass
        if r.stop_reason == "pause_turn":
            msgs = [msgs[0], {"role": "assistant", "content": r.content}]; continue
        msgs += [{"role": "assistant", "content": text or "..."},
                 {"role": "user", "content": "Return ONLY the valid JSON array now."}]
    return []

def days_left(o):
    try: return (dt.date.fromisoformat(o["deadline"]) - TODAY).days
    except Exception: return None

def row(o, new=False):
    d = days_left(o)
    dl = o.get("deadline") or "check site"
    if d is not None: dl += f" ({d}d)"
    tag = " 🆕" if new else ""
    return (f"<tr><td><b>{o.get('fit_score',0)}</b></td><td><a href='{escape(o.get('url') or '#')}'>{escape(o.get('title',''))}</a>{tag}"
            f"<br><small>{escape(o.get('institution',''))} · {escape(o.get('country',''))} · {escape(o.get('kind',''))}</small></td>"
            f"<td>{escape(dl)}</td><td>{escape(str(o.get('funding') or '?'))}</td>"
            f"<td>{escape(o.get('why_fit',''))}<br><small style='color:#b45309'>⚠ {escape(str(o.get('risks') or '-'))}</small></td></tr>")

def page(title, items, new_keys=()):
    rows = "".join(row(o, k in new_keys) for k, o in items)
    return (f"<html><body style='font-family:system-ui;max-width:1100px;margin:auto;padding:16px'><h2>{title}</h2>"
            f"<table border=0 cellpadding=8 style='border-collapse:collapse;width:100%'>"
            f"<tr style='text-align:left;border-bottom:2px solid #999'><th>Fit</th><th>Opportunity</th><th>Deadline</th><th>Funding</th><th>Why / Risks</th></tr>"
            f"{rows}</table></body></html>")

def main():
    db = json.loads(DB.read_text()) if DB.exists() else {}
    new = {}
    for region in profile["regions"]:
        try: found = scout(region)
        except Exception as e: print("FAILED", region, e); continue
        print(f"{region[:20]}: {len(found)} results")
        for o in found:
            if not isinstance(o, dict) or int(o.get("fit_score") or 0) < MIN_SCORE: continue
            k = key(o)
            if k in db:
                db[k].update({f: o[f] for f in ("deadline", "fit_score", "funding") if o.get(f)}); continue
            o.update(first_seen=TODAY.isoformat(), status="new")
            db[k] = new[k] = o
        time.sleep(2)
    DB.write_text(json.dumps(db, indent=1, ensure_ascii=False))

    live = [(k, o) for k, o in db.items() if (days_left(o) is None or days_left(o) >= 0) and o.get("status") != "ignored"]
    live.sort(key=lambda kv: -int(kv[1].get("fit_score") or 0))
    (DOCS / "index.html").write_text(page(f"Masters Scout, updated {TODAY}", live, new))
    with open(ROOT / "applications.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["status","fit","title","institution","country","kind","deadline","funding","url","risks","first_seen"])
        for k, o in live:
            w.writerow([o.get("status"), o.get("fit_score"), o.get("title"), o.get("institution"), o.get("country"),
                        o.get("kind"), o.get("deadline"), o.get("funding"), o.get("url"), o.get("risks"), o.get("first_seen")])

    soon = [(k, o) for k, o in live if days_left(o) is not None and days_left(o) <= 30]
    newl = sorted(new.items(), key=lambda kv: -int(kv[1].get("fit_score") or 0))
    body = (page(f"{len(newl)} new opportunities today", newl, new)
            + (page("⏰ Closing within 30 days", soon) if soon else "")
            + f"<p>Total tracked: {len(live)}. Always verify deadlines on the official page.</p>")
    (DOCS / "latest_digest.html").write_text(body)
    print(f"{len(newl)} new, {len(live)} tracked")

    if os.getenv("SMTP_USER") and os.getenv("SMTP_PASS") and (newl or soon):
        msg = MIMEText(body, "html"); msg["Subject"] = f"Masters Scout {TODAY}: {len(newl)} new"
        msg["From"] = os.environ["SMTP_USER"]; msg["To"] = os.getenv("MAIL_TO", os.environ["SMTP_USER"])
        with smtplib.SMTP_SSL(os.getenv("SMTP_HOST", "smtp.gmail.com"), 465) as s:
            s.login(os.environ["SMTP_USER"], os.environ["SMTP_PASS"]); s.send_message(msg)

if __name__ == "__main__":
    main()
